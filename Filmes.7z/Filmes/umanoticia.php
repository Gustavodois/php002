<?php include "cabecalho.php"; ?>
<div class="container">
    <img src="img/noticia1.png">
     <h2>Quarteto Fantástico | Diretor revela quadrinhos que inspiraram o novo filme</h2>
    <p>Lorem ipsum dolor sit amet consectetur, adipisicing elit. Saepe veritatis commodi ab, molestias corrupti, qui nihil unde praesentium harum dicta atque dignissimos! Quis, alias eaque accusamus cumque amet officia velit?</p>
</div>
<?php include "rodape.php"; ?>