Qual nome do projeto?

R: MovieFlix.

Sobre o que é o projeto?

R: Um site que utiliza PHP de Filmes.

Quais foram os principais recursos do PHP utilizado?

R: include e echo.

Qual aprendizado você leva desse projeto?

R: Facilidade em reutilizar códigos sem precisar copiar e colar.